package dev.nx2android.mobile

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.ViewGroup
import android.graphics.Typeface
import android.graphics.Color
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.content.pm.PackageManager
import java.util.Locale

class MainActivity : Activity() {
    private val pickFileCode = 7102
    private lateinit var status: TextView
    private lateinit var deviceInfo: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(15, 22, 38)
        window.navigationBarColor = Color.rgb(15, 22, 38)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(24))
            setBackgroundColor(Color.rgb(12, 17, 29))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(12))
        }
        scroll.addView(content)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        content.addView(text("NX2Android Mobile", 27, Color.WHITE, true))
        content.addView(text("Android compatibility checker • prototype", 14, Color.rgb(158, 177, 211), false).withTop(5))
        content.addView(panel(
            "Important",
            "This is an early Android companion. It does not yet convert a Switch game into an APK. Selecting a file only inspects basic metadata; it does not upload your file."
        ).withTop(22))

        val pick = Button(this).apply {
            text = "Choose game file"
            textSize = 16f
            setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                startActivityForResult(intent, pickFileCode)
            }
        }
        content.addView(pick, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(18) })

        status = text("No file selected", 15, Color.WHITE, true).withTop(14)
        content.addView(status)
        deviceInfo = text(deviceReport(), 14, Color.rgb(210, 220, 238), false).withTop(16)
        content.addView(panel("Device check", deviceReport()).withTop(14))
        content.addView(panel(
            "What this check means",
            "A compatible Snapdragon GPU is only one prerequisite. Actual support depends on the specific game's profile, texture formats, runtime services, and a working port pipeline. This app does not claim the selected game is playable."
        ).withTop(14))
        content.addView(panel(
            "Next development step",
            "Integrate or rework the upstream nx2android porting pipeline for Android, then validate memory use, NDK/.NET dependencies and shader translation on the target tablet."
        ).withTop(14))

        setContentView(page)
    }

    private fun deviceReport(): String {
        val abis = Build.SUPPORTED_ABIS.joinToString()
        val vulkanFeature = packageManager.hasSystemFeature(PackageManager.FEATURE_VULKAN_HARDWARE_LEVEL)
        val vulkanVersion = if (Build.VERSION.SDK_INT >= 24) {
            packageManager.systemAvailableFeatures
                .firstOrNull { it.name == PackageManager.FEATURE_VULKAN_HARDWARE_LEVEL }
                ?.version?.toString() ?: "not reported"
        } else "API too old"
        return "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\\nABI: $abis\\nVulkan hardware feature: ${if (vulkanFeature) "reported" else "not reported"}\\nVulkan feature level: $vulkanVersion\\n\\nThis does not verify BC texture support or guarantee nx2android compatibility."
    }

    @Deprecated("Uses the platform activity result API for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickFileCode || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        val nameAndSize = queryNameAndSize(uri)
        val ext = nameAndSize.first.substringAfterLast('.', "").lowercase(Locale.ROOT)
        val formatNote = when (ext) {
            "nsp", "xci" -> "File extension resembles a supported input format in the desktop workflow; the app has not validated its contents."
            "nsz" -> "NSZ is not accepted directly by the upstream workflow; it needs conversion to NSP first."
            else -> "This extension is not enough to determine whether the file is usable."
        }
        status.text = "Selected: ${nameAndSize.first}\\nSize: ${nameAndSize.second}\\n$formatNote\\n\\nNo conversion has been started."
    }

    private fun queryNameAndSize(uri: Uri): Pair<String, String> {
        var name = uri.lastPathSegment ?: "Unknown file"
        var size = -1L
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val si = c.getColumnIndex(OpenableColumns.SIZE)
                if (ni >= 0) name = c.getString(ni) ?: name
                if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
            }
        }
        val readable = if (size < 0) "Unknown" else when {
            size >= 1024L * 1024 * 1024 -> String.format(Locale.US, "%.2f GiB", size / (1024.0 * 1024 * 1024))
            size >= 1024L * 1024 -> String.format(Locale.US, "%.1f MiB", size / (1024.0 * 1024))
            size >= 1024L -> String.format(Locale.US, "%.1f KiB", size / 1024.0)
            else -> "$size bytes"
        }
        return name to readable
    }

    private fun panel(title: String, body: String): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            setBackgroundColor(Color.rgb(25, 34, 53))
        }
        box.addView(text(title, 16, Color.rgb(143, 181, 255), true))
        box.addView(text(body.replace("\\\\n", "\\n"), 14, Color.rgb(222, 229, 243), false).withTop(8))
        return box
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setLineSpacing(dp(3).toFloat(), 1f)
        }

    private fun ViewGroup.withTop(top: Int): ViewGroup = this.apply {
        val lp = layoutParams
        if (lp != null) {
            lp.topMargin = dp(top)
            layoutParams = lp
        } else {
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) }
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
