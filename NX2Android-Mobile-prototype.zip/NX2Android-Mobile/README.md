# NX2Android Mobile (prototype)

An Android companion/prototype for the nx2android project. It checks a selected file/folder and reports basic device capability signals. **It does not yet port Nintendo Switch games or generate game APKs.**

## Why this is a prototype
The upstream `shirai91/nx2android` v0.1.2 workflow is a Windows desktop pipeline requiring Python, Android NDK r27c, .NET SDK 10, platform-tools, game-specific profiles and user-supplied files/keys. An Android UI alone cannot replace that pipeline. This starter creates a native Android app and a GitHub Actions build so the UI and device checks can be tested first.

## Build
- Open this folder in Android Studio (recent version) and sync Gradle, or
- Push the folder to a GitHub repository. GitHub Actions builds a debug APK on each push at `.github/workflows/android.yml`.
- The artifact is named `nx2android-mobile-debug-apk`.

## Current functionality
- Select a local file using Android's Storage Access Framework.
- Display filename, extension, size, Android version, ABI and available Vulkan feature signal.
- Show a clear warning that file selection is not a compatibility guarantee.
- No game files or keys are uploaded.

## Known limits
- Does not parse/decrypt NSP/XCI, read prod.keys, run the upstream porter, translate shaders, or create/install a game APK.
- Device GPU capability checks are preliminary; Vulkan extension support is not proof of BC texture support or game compatibility.
- To become a real on-device porting tool, the upstream Python pipeline and its NDK/.NET dependencies must be ported or reworked and benchmarked on the target device.

Upstream: https://github.com/shirai91/nx2android
